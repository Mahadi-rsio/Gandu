(function($) {
	$.fn.loginModal = function(options) {
		const settings = $.extend({
			buttonText: 'Login',
			themeColors: {
				background: '#f8f9fa',
				surface: '#ffffff',
				primary: '#4a90e2',
				secondary: '#6c757d',
				accent: '#dc3545',
				text: '#212529'
			},
			onLoginSuccess: function() {},
			onLoginError: function() {}
		}, options);

		// Inject styles
		const style = document.createElement('style');
		style.textContent = `
            .login-modal-container * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
                font-family: 'Inter', sans-serif;
            }

            .login-modal-container {
                --background: ${settings.themeColors.background};
                --surface: ${settings.themeColors.surface};
                --primary: ${settings.themeColors.primary};
                --secondary: ${settings.themeColors.secondary};
                --accent: ${settings.themeColors.accent};
                --text-color: ${settings.themeColors.text};
                --border-color: rgba(0, 0, 0, 0.1);
            }

            .login-button {
                padding: 12px 24px;
                background: var(--primary);
                color: white;
                border: none;
                border-radius: 4px;
                cursor: pointer;
                transition: all 0.3s ease;
                font-weight: 500;
            }

            .login-button:hover {
                opacity: 0.9;
                transform: translateY(-1px);
            }

            .login-modal-overlay {
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: rgba(0, 0, 0, 0.5);
                display: none;
                justify-content: center;
                align-items: center;
                z-index: 1000;
            }

            .login-container {
                background: var(--surface);
                padding: 2rem;
                border-radius: 10px;
                width: 90%;
                max-width: 400px;
                transform: scale(0.9);
                opacity: 0;
                transition: all 0.3s ease;
                position: relative;
                box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
                border: 1px solid var(--border-color);
            }

            .login-container.active {
                transform: scale(1);
                opacity: 1;
            }

            .close-button {
                position: absolute;
                top: 1rem;
                right: 1rem;
                background: none;
                border: none;
                color: var(--text-color);
                font-size: 1.5rem;
                cursor: pointer;
                padding: 0.25rem;
                opacity: 0.7;
            }

            .login-form {
                display: flex;
                flex-direction: column;
                gap: 1.5rem;
                color: var(--text-color);
            }

            .login-form h2 {
                text-align: center;
                margin-bottom: 1rem;
                color: var(--text-color);
            }

            .material-textfield {
                position: relative;
            }

            .material-textfield input {
                width: 100%;
                padding: 1rem;
                background: var(--background);
                border: 1px solid var(--border-color);
                border-radius: 4px;
                color: var(--text-color);
                font-size: 1rem;
            }

            .material-textfield label {
                position: absolute;
                left: 1rem;
                top: 50%;
                transform: translateY(-50%);
                color: rgba(0, 0, 0, 0.6);
                pointer-events: none;
                transition: all 0.3s ease;
                background: var(--background);
                padding: 0 0.25rem;
            }

            .material-textfield input:focus ~ label,
            .material-textfield input:valid ~ label {
                top: 0;
                left: 0.8rem;
                font-size: 0.8rem;
                color: var(--primary);
            }

            .password-toggle {
                position: absolute;
                right: 1rem;
                top: 50%;
                transform: translateY(-50%);
                background: none;
                border: none;
                color: rgba(0, 0, 0, 0.6);
                cursor: pointer;
            }

            .password-toggle svg {
                width: 1.5rem;
                height: 1.5rem;
            }

            .eye-closed {
                display: none;
            }

            .password-toggle.active .eye-open {
                display: none;
            }

            .password-toggle.active .eye-closed {
                display: block;
            }

            .options-container {
                display: flex;
                justify-content: space-between;
                align-items: center;
                font-size: 0.9rem;
            }

            .remember-me {
                display: flex;
                align-items: center;
                gap: 0.5rem;
                color: var(--text-color);
            }

            .remember-me-check {
                accent-color: var(--primary);
            }

            .forgot-password {
                color: var(--primary);
                text-decoration: none;
            }

            .login-button-modal {
                background: var(--primary);
                color: white;
                padding: 1rem;
                border: none;
                border-radius: 4px;
                cursor: pointer;
                position: relative;
                transition: all 0.3s ease;
            }

            .login-button-modal:hover {
                opacity: 0.9;
            }

            .loading-spinner {
                width: 1.5rem;
                height: 1.5rem;
                border: 3px solid rgba(255, 255, 255, 0.3);
                border-top-color: white;
                border-radius: 50%;
                animation: spin 1s linear infinite;
                position: absolute;
                left: 50%;
                top: 50%;
                transform: translate(-50%, -50%);
                display: none;
            }

            @keyframes spin {
                to { transform: translate(-50%, -50%) rotate(360deg); }
            }

            .register-container {
                text-align: center;
                font-size: 0.9rem;
                color: var(--text-color);
            }

            .register-container a {
                color: var(--primary);
                text-decoration: none;
            }

            .error-message {
                color: var(--accent);
                background: rgba(220, 53, 69, 0.1);
                padding: 0.8rem;
                border-radius: 4px;
                display: none;
                font-size: 0.9rem;
            }
        `;
		document.head.appendChild(style);

		// Create modal HTML structure
		const modalHTML = `
            <div class="login-modal-overlay">
                <div class="login-container">
                    <button class="close-button">&times;</button>
                    <form class="login-form">
                        <h2>Welcome Back</h2>
                        <div class="error-message"></div>
                        
                        <div class="material-textfield">
                            <input type="text" id="username" required>
                            <label for="username">Username</label>
                        </div>
                        
                        <div class="material-textfield">
                            <input type="password" id="password" class="password-input" required>
                            <label for="password">Password</label>
                            <button type="button" class="password-toggle">
                                <svg viewBox="0 0 24 24" fill="currentColor">
                                    <path class="eye-open" d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z"/>
                                    <path class="eye-closed" d="M12 7c2.76 0 5 2.24 5 5 0 .65-.13 1.26-.36 1.83l2.92 2.92c1.51-1.26 2.7-2.89 3.43-4.75-1.73-4.39-6-7.5-11-7.5-1.4 0-2.74.25-3.98.7l2.16 2.16C10.74 7.13 11.35 7 12 7zM2 4.27l2.28 2.28.46.46C3.08 8.3 1.78 10.02 1 12c1.73 4.39 6 7.5 11 7.5 1.55 0 3.03-.3 4.38-.84l.42.42L19.73 22 21 20.73 3.27 3 2 4.27zM7.53 9.8l1.55 1.55c-.05.21-.08.43-.08.65 0 1.66 1.34 3 3 3 .22 0 .44-.03.65-.08l1.55 1.55c-.67.33-1.41.53-2.2.53-2.76 0-5-2.24-5-5 0-.79.2-1.53.53-2.2zm4.31-.78l3.15 3.15.02-.16c0-1.66-1.34-3-3-3l-.17.01z"/>
                                </svg>
                            </button>
                        </div>

                        <div class="options-container">
                            <label class="remember-me">
                                <input type="checkbox" class="remember-me-check">
                                Remember me
                            </label>
                            <a href="#" class="forgot-password">Forgot Password?</a>
                        </div>

                        <button type="submit" class="login-button-modal">
                            <span>Sign In</span>
                            <div class="loading-spinner"></div>
                        </button>

                        <div class="register-container">
                            Don't have an account? <a href="#" class="register-link">Register here</a>
                        </div>
                    </form>
                </div>
            </div>
        `;

		// Initialize plugin (same initialization code as before)
		// ... [keep the same JavaScript initialization code from previous answer]
	};
})(jQuery);