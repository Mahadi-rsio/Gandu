(function($) {
	
	window.stats_panel = function(options,icon) {
		
		var statsIcon = $('<button id="stats-icon"></button>').css({
			position: 'fixed',
			bottom: '20px',
			right: '20px',
			fontSize: '25px',
			backgroundColor: 'darkslateblue',
			color: 'white',
			border: 'none',
			borderRadius : '45%',
			padding: '10px',
			cursor: 'pointer',
			zIndex: 999,
			boxShadow: '0 4px 10px rgba(0, 0, 0, 0.3)'
		});

		var statsPanel = $('<div id="stats-panel"></div>').css({
			position: 'fixed',
			bottom: '-300px',
			left: '0',
			width: '100%',
			backgroundColor: 'rgba(10, 10, 20)',
			color: 'white',
			fontFamily: 'Arial, sans-serif',
			fontSize: '14px',
			padding: '20px',
			boxShadow: '0 -2px 5px rgba(0, 0, 0, 0.2)',
			transition: 'bottom 0.5s ease-in-out',
			zIndex: 998
		});

		// Function to populate the stats panel
		function updatePanel(options) {
			statsPanel.empty(); // Clear any existing content in the panel
			options.forEach(function(option) {
				var pElement = $('<p></p>');
				var strongText = $('<strong></strong>').text(option.label + ": ");
				var normalText = document.createTextNode(option.value);

				pElement.append(strongText).append(normalText);
				statsPanel.append(pElement);
			});
		}

		// Populate the panel with options
		updatePanel(options);

		// Append the stats icon button and panel to the body
		$('body').append(statsIcon).append(statsPanel);

		// Toggle panel visibility when the stats icon is clicked
		statsIcon.click(function() {
			if (statsPanel.css('bottom') === '0px') {
				statsPanel.css('bottom', '-300px'); // Hide the panel
			} else {
				statsPanel.css('bottom', '0px'); // Show the panel
			}
		});
	};
})(jQuery);