(function($) {
	// Exportable function to show the login modal
	window.login_popup = function() {
		// Dynamically create modal HTML with jQuery only if it doesn't already exist
		if ($('#loginModal').length === 0) {
			var modalHTML = `
                <div id="loginModal" class="modal" tabindex="-1" aria-labelledby="loginModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content bg-dark text-light">
                            <div class="modal-header bg-dark d-flex justify-content-between align-items-center">
                                <h1 class="text-info mb-0" id="loginModalLabel">Sign in</h1>
                                <button type="button" class="btn-close btn-close-white" id="close-modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body" id="card-body">
                                <form id="sign-in-form">
                                    <input type="text" id="username-email" class="form-control mb-4" placeholder="Enter email or username" required>
                                    <input type="password" id="password" class="form-control mb-3" placeholder="Enter Password" required>
                                    <div>
                                        <button type="submit" class="btn btn-outline-info btn-sm w-25">
                                            <span class="fa fa-check"></span> Submit
                                        </button>
                                        <span class="mx-2">or</span>
                                        <button type="button" class="btn btn-outline-info btn-sm w-25" id="register-btn">
                                            <span class="fa fa-sign-in"></span> Register
                                        </button>
                                    </div>
                                </form>
                                <a class="text-info forgot-password" id="forgot-password">Forgot Password?</a>
                            </div>
                        </div>
                    </div>
                </div>
            `;

			// Append the modal to the body (but keep it hidden by default)
			$('body').append(modalHTML);
			$('#loginModal').hide(); // Initially hide the modal
		}

		// Show the modal content with fade-in effect
		$('#loginModal').fadeIn();

		// Close the modal with fade-out effect
		$('#close-modal').click(function() {
			$('#loginModal').fadeOut(function() {
				$('#loginModal').remove(); // Remove modal from DOM after fade out
			});
		});

		// Submit form - Show verification message
		$("#sign-in-form").submit(function(event) {
			event.preventDefault();
			showVerificationMessage();
		});

		// Register button click event
		$("#register-btn").click(function() {
			let userInput = $("#username-email").val();

			if (userInput.includes("@")) {
				// If it's an email, directly show verification message
				showVerificationMessage("Check your email");
			} else {
				// If it's a username, ask for an email first
				$("#card-body").html(`
                    <form id="email-form">
                        <input type="email" id="email-input" class="form-control mb-3" placeholder="Enter your email" required>
                        <button type="submit" class="btn btn-outline-info btn-sm w-100">Submit</button>
                    </form>
                `);

				$("#email-form").submit(function(event) {
					event.preventDefault();
					showVerificationMessage("Check your email");
				});
			}
		});

		// Forgot Password click event
		$("#forgot-password").click(function() {
			$("#card-body").html(`
                <form id="forgot-password-form">
                    <input type="email" id="forgot-email-input" class="form-control mb-3" placeholder="Enter your email" required>
                    <button type="submit" class="btn btn-outline-info btn-sm w-100">Submit</button>
                </form>
            `);

			$("#forgot-password-form").submit(function(event) {
				event.preventDefault();
				showVerificationMessage("Check your email");
			});
		});

		// Function to show verification message
		function showVerificationMessage(message = "") {
			$("#card-body").html(`
                <div class="d-flex flex-column justify-content-center align-items-center" style="height: 200px;">
                    <i class="fa fa-check-circle verification-icon"></i>
                    <p class="text-info mt-3">${message}</p>
                </div>
            `);
		}
	};
})(jQuery);